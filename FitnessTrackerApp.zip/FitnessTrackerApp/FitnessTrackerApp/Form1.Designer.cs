﻿

namespace FitnessTrackerApp;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }



    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        labelUsername = new Label();
        labelPassword = new Label();
        textBoxUsername = new TextBox();
        textBoxPassword = new TextBox();
        buttonLogin = new Button();
        labelGoal = new Label();
        textBoxGoal = new TextBox();
        buttonSetGoal = new Button();
        labelActivity = new Label();
        comboBoxActivity = new ComboBox();
        labelMetric1 = new Label();
        labelMetric2 = new Label();
        labelMetric3 = new Label();
        textBoxMetric1 = new TextBox();
        textBoxMetric2 = new TextBox();
        textBoxMetric3 = new TextBox();
        buttonRecordActivity = new Button();
        labelProgress = new Label();
        labelCaloriesBurned = new Label();
        buttonRegister = new Button();
        Progressbutton = new Button();
        label1 = new Label();
        SuspendLayout();
        // 
        // labelUsername
        // 
        labelUsername.AutoSize = true;
        labelUsername.Location = new Point(162, 24);
        labelUsername.Name = "labelUsername";
        labelUsername.Size = new Size(60, 15);
        labelUsername.TabIndex = 0;
        labelUsername.Text = "Username";
        labelUsername.Click += label1_Click;
        // 
        // labelPassword
        // 
        labelPassword.AutoSize = true;
        labelPassword.Location = new Point(162, 64);
        labelPassword.Name = "labelPassword";
        labelPassword.Size = new Size(57, 15);
        labelPassword.TabIndex = 2;
        labelPassword.Text = "Password";
        // 
        // textBoxUsername
        // 
        textBoxUsername.Location = new Point(232, 24);
        textBoxUsername.Name = "textBoxUsername";
        textBoxUsername.Size = new Size(156, 23);
        textBoxUsername.TabIndex = 1;
        textBoxUsername.TextChanged += textBoxUsername_TextChanged;
        // 
        // textBoxPassword
        // 
        textBoxPassword.Location = new Point(232, 64);
        textBoxPassword.Name = "textBoxPassword";
        textBoxPassword.Size = new Size(156, 23);
        textBoxPassword.TabIndex = 3;
        textBoxPassword.UseSystemPasswordChar = true;
        // 
        // buttonLogin
        // 
        buttonLogin.Location = new Point(232, 115);
        buttonLogin.Name = "buttonLogin";
        buttonLogin.Size = new Size(75, 23);
        buttonLogin.TabIndex = 4;
        buttonLogin.Text = "Login";
        buttonLogin.UseVisualStyleBackColor = true;
        buttonLogin.Click += buttonLogin_Click;
        // 
        // labelGoal
        // 
        labelGoal.AutoSize = true;
        labelGoal.Location = new Point(177, 147);
        labelGoal.Name = "labelGoal";
        labelGoal.Size = new Size(31, 15);
        labelGoal.TabIndex = 5;
        labelGoal.Text = "Goal";
        // 
        // textBoxGoal
        // 
        textBoxGoal.Location = new Point(247, 147);
        textBoxGoal.Name = "textBoxGoal";
        textBoxGoal.Size = new Size(150, 23);
        textBoxGoal.TabIndex = 6;
        // 
        // buttonSetGoal
        // 
        buttonSetGoal.Location = new Point(291, 176);
        buttonSetGoal.Name = "buttonSetGoal";
        buttonSetGoal.Size = new Size(75, 23);
        buttonSetGoal.TabIndex = 7;
        buttonSetGoal.Text = "Set Goal";
        buttonSetGoal.UseVisualStyleBackColor = true;
        buttonSetGoal.Click += buttonSetGoal_Click;
        // 
        // labelActivity
        // 
        labelActivity.AutoSize = true;
        labelActivity.Location = new Point(177, 217);
        labelActivity.Name = "labelActivity";
        labelActivity.Size = new Size(47, 15);
        labelActivity.TabIndex = 8;
        labelActivity.Text = "Activity";
        // 
        // comboBoxActivity
        // 
        comboBoxActivity.FormattingEnabled = true;
        comboBoxActivity.Items.AddRange(new object[] { "Walking", "Swimming", "Cycling", "Running", "Yoga", "Jumping Rope" });
        comboBoxActivity.Location = new Point(247, 217);
        comboBoxActivity.Name = "comboBoxActivity";
        comboBoxActivity.Size = new Size(150, 23);
        comboBoxActivity.TabIndex = 9;
        // 
        // labelMetric1
        // 
        labelMetric1.AutoSize = true;
        labelMetric1.Location = new Point(177, 257);
        labelMetric1.Name = "labelMetric1";
        labelMetric1.Size = new Size(60, 15);
        labelMetric1.TabIndex = 10;
        labelMetric1.Text = "MetricsA1";
        labelMetric1.Click += labelMetric1_Click;
        // 
        // labelMetric2
        // 
        labelMetric2.AutoSize = true;
        labelMetric2.Location = new Point(177, 287);
        labelMetric2.Name = "labelMetric2";
        labelMetric2.Size = new Size(60, 15);
        labelMetric2.TabIndex = 12;
        labelMetric2.Text = "MetricsA2";
        // 
        // labelMetric3
        // 
        labelMetric3.AutoSize = true;
        labelMetric3.Location = new Point(177, 317);
        labelMetric3.Name = "labelMetric3";
        labelMetric3.Size = new Size(60, 15);
        labelMetric3.TabIndex = 14;
        labelMetric3.Text = "MetricsA3";
        labelMetric3.Click += labelMetric3_Click;
        // 
        // textBoxMetric1
        // 
        textBoxMetric1.Location = new Point(247, 257);
        textBoxMetric1.Name = "textBoxMetric1";
        textBoxMetric1.Size = new Size(150, 23);
        textBoxMetric1.TabIndex = 11;
        // 
        // textBoxMetric2
        // 
        textBoxMetric2.Location = new Point(247, 287);
        textBoxMetric2.Name = "textBoxMetric2";
        textBoxMetric2.Size = new Size(150, 23);
        textBoxMetric2.TabIndex = 13;
        // 
        // textBoxMetric3
        // 
        textBoxMetric3.Location = new Point(247, 317);
        textBoxMetric3.Name = "textBoxMetric3";
        textBoxMetric3.Size = new Size(150, 23);
        textBoxMetric3.TabIndex = 15;
        // 
        // buttonRecordActivity
        // 
        buttonRecordActivity.Location = new Point(267, 346);
        buttonRecordActivity.Name = "buttonRecordActivity";
        buttonRecordActivity.Size = new Size(102, 23);
        buttonRecordActivity.TabIndex = 16;
        buttonRecordActivity.Text = "Record Activity";
        buttonRecordActivity.UseVisualStyleBackColor = true;
        buttonRecordActivity.Click += buttonRecordActivity_Click;
        // 
        // labelProgress
        // 
        labelProgress.AutoSize = true;
        labelProgress.Location = new Point(177, 387);
        labelProgress.Name = "labelProgress";
        labelProgress.RightToLeft = RightToLeft.No;
        labelProgress.Size = new Size(90, 15);
        labelProgress.TabIndex = 17;
        labelProgress.Text = "Calories Burned";
        // 
        // labelCaloriesBurned
        // 
        labelCaloriesBurned.AutoSize = true;
        labelCaloriesBurned.Location = new Point(297, 387);
        labelCaloriesBurned.Name = "labelCaloriesBurned";
        labelCaloriesBurned.Size = new Size(58, 15);
        labelCaloriesBurned.TabIndex = 18;
        labelCaloriesBurned.Text = "% burned";
        // 
        // buttonRegister
        // 
        buttonRegister.Location = new Point(313, 115);
        buttonRegister.Name = "buttonRegister";
        buttonRegister.Size = new Size(75, 23);
        buttonRegister.TabIndex = 19;
        buttonRegister.Text = "Register";
        buttonRegister.UseVisualStyleBackColor = true;
        buttonRegister.Click += buttonRegister_Click;
        // 
        // Progressbutton
        // 
        Progressbutton.Location = new Point(269, 405);
        Progressbutton.Name = "Progressbutton";
        Progressbutton.Size = new Size(100, 23);
        Progressbutton.TabIndex = 20;
        Progressbutton.Text = "Viewprogress";
        Progressbutton.UseVisualStyleBackColor = true;
        Progressbutton.Click += Progressbutton_Click;
        // 
        // label1
        // 
        label1.AutoSize = true;
        label1.Location = new Point(66, 97);
        label1.Name = "label1";
        label1.Size = new Size(466, 15);
        label1.TabIndex = 21;
        label1.Text = "Characters count must be equal to 12, atleast ONE lowercase and ONE uppercase letter.";
        label1.Click += label1_Click_1;
        // 
        // Form1
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(570, 479);
        Controls.Add(label1);
        Controls.Add(Progressbutton);
        Controls.Add(buttonRegister);
        Controls.Add(labelCaloriesBurned);
        Controls.Add(labelProgress);
        Controls.Add(buttonRecordActivity);
        Controls.Add(textBoxMetric3);
        Controls.Add(textBoxMetric2);
        Controls.Add(textBoxMetric1);
        Controls.Add(labelMetric3);
        Controls.Add(labelMetric2);
        Controls.Add(labelMetric1);
        Controls.Add(comboBoxActivity);
        Controls.Add(labelActivity);
        Controls.Add(buttonSetGoal);
        Controls.Add(textBoxGoal);
        Controls.Add(labelGoal);
        Controls.Add(buttonLogin);
        Controls.Add(textBoxPassword);
        Controls.Add(textBoxUsername);
        Controls.Add(labelPassword);
        Controls.Add(labelUsername);
        Name = "Form1";
        Text = "FitnessTracker";
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion

    private Label labelUsername;
    private Label labelPassword;
    private TextBox textBoxUsername;
    private TextBox textBoxPassword;
    private Button buttonLogin;
    private Label labelGoal;
    private TextBox textBoxGoal;
    private Button buttonSetGoal;
    private Label labelActivity;
    private ComboBox comboBoxActivity;
    private Label labelMetric1;
    private Label labelMetric2;
    private Label labelMetric3;
    private TextBox textBoxMetric1;
    private TextBox textBoxMetric2;
    private TextBox textBoxMetric3;
    private Button buttonRecordActivity;
    private Label labelProgress;
    private Label labelCaloriesBurned;
    private Button buttonRegister;
    private Button Progressbutton;
    private Label label1;
}
