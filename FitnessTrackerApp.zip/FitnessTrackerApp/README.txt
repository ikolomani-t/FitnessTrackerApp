THIS APPLICATION IS ONLY MEANT FOR EDUCATIONAL PURPOSES ONLY ANY USE OR CHANGES 
ARE ALLOWED BUT AT YOUR OWN RISK.
This application uses MsSQL database to store users information and for aunthetication 
purposes

You can download the MS SQL Server and SSMS for Windows on this website>>
https://hasura.io/learn/database/microsoft-sql-server/installation/1-installing-mssql-windows/

Follow the instruction on the link to install the two softwares

>>You can also install visual studio code or visual studio IDE(recommended) on your windows.

>>After installation is complete of the MS SQL Server and SSMS open the SSMS and create 
  database by the name FitnessTrackerDB, use the command int the SSMS.

    CREATE DATABASE FitnessTrackerDB;

>>Within the FitnessTrackerDB database create two tables Activities and Users
   *You can use below SQLQUERIES to create the two tables
     
    CREATE TABLE Users(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL,
    Password NVARCHAR(50) NOT NULL,
    CalorieGoal INT NOT NULL);

    CREATE TABLE Activities(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50),
    ActivityName NVARCHAR(50),
    Metric1 INT,
    Metric2 INT,
    Metric3 INT);

>>That is all for the database side
>>NOTE: Use the following as the database connection string(assumming you have used same
  database configuration as this file stipulates for windows only)
    
    string connectionString = "Server=localhost;Database=FitnessTrackerDB;Trusted_Connection=True;";

>>This article assumming you are accessing local server if remote replace the server variable with
  remote IP address.

    
     
