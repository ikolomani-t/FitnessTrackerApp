using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic.ApplicationServices;
using System.Diagnostics;



namespace FitnessTrackerApp;

public partial class Form1 : Form
{
    //insert your connection string incase you use the different database name
    string connectionString = "Server=localhost;Database=FitnessTrackerDB;Trusted_Connection=True;";
    User currentUser;//create the user instance
    public Form1()
    {
        InitializeComponent();
        labelGoal.Visible = false;
        textBoxGoal.Visible = false;
        buttonSetGoal.Visible = false;
        labelActivity.Visible = false;
        comboBoxActivity.Visible = false;
        labelMetric1.Visible = false;
        labelMetric2.Visible = false;
        labelMetric3.Visible = false;
        textBoxMetric1.Visible = false;
        textBoxMetric2.Visible = false;
        textBoxMetric3.Visible = false;
        buttonRecordActivity.Visible = false;
        labelProgress.Visible = false;
        labelCaloriesBurned.Visible = false;
        Progressbutton.Visible = false;
    }


    private void RegisterButton_Click(object sender, EventArgs e)//register the click button for registration
    {
        string username = textBoxUsername.Text;//get the information from the form text box and insert it in the username string variable
        string password = textBoxPassword.Text;//get the information from the form password textbox and insert it in the password string  variable
                                               //use the IsValidUsername() IsValidPassword() to check the validity of the entered username and password by the user
        if (!IsValidUsername(username) || !IsValidPassword(password))
        {
            MessageBox.Show("Invalid username or password format.");
            return;
        }
        //connecting to the Ms SQL database defined by the connection string
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            // Checking  if user pre-exist or not
            string checkUserQuery = "SELECT COUNT(*) FROM Users WHERE Username = @username";
            SqlCommand checkCmd = new SqlCommand(checkUserQuery, connection);
            checkCmd.Parameters.AddWithValue("@username", username);
            int userExists = (int)checkCmd.ExecuteScalar();

            if (userExists == 0)//if the checkCmd.ExecuteScalar() returns zero then the user does not exist
            {
                // if the user does not exist the add a new user
                string insertUserQuery = "INSERT INTO Users (Username, Password, CalorieGoal) VALUES (@username, @password, 0)";
                SqlCommand insertCmd = new SqlCommand(insertUserQuery, connection);
                insertCmd.Parameters.AddWithValue("@username", username);
                insertCmd.Parameters.AddWithValue("@password", password);
                insertCmd.ExecuteNonQuery();

                MessageBox.Show("User registered successfully!");//database feedback
            }
            else
            {
                MessageBox.Show("Username already exists.");//if checkCmd.ExecuteScalar() retuns a non zero value then the user exist
            }
        }
    }

    private bool IsValidPassword(string password)
    {
        return password.Length == 12 && Regex.IsMatch(password, "[a-z]") && Regex.IsMatch(password, "[A-Z]");
    }

    private bool IsValidUsername(string username)
    {
        return Regex.IsMatch(username, "^[a-zA-Z0-9]+$");
    }

    private void LoginButton_Click(object sender, EventArgs e) //register login button 
    {

    }
    //This function obtains the information provided by the user in the set goal text box, connects to the database and updates the goal of the user.
    private void SetGoalButton_Click(object sender, EventArgs e)
    {

    }
    //This function collects information from the three text boxes and inserts them in the three int variables which later are sent to the database for storage.
    private void RecordActivityButton_Click(object sender, EventArgs e)
    {

    }
    //This function maps the progress of user toward their goals by tracking their metrics that is stored in the database
    private void ViewProgressButton_Click(object sender, EventArgs e)
    {

    }
    //defined user class 
    public class User
    {
        public string Username { get; set; }
        private string Password { get; set; }
        public int CalorieGoal { get; set; }

        public User(string username, string password, int calorieGoal)//user class constructor initializes the variables
        {
            Username = username;
            Password = password;
            CalorieGoal = calorieGoal;
        }
        //compare the user provided password in the text box and the stored password in the database
        public bool ValidatePassword(string password)
        {
            return Password == password;
        }
        //set the calorific goal value in the database (the goal source value is obtained from the windows form textbox)
        public void SetCalorieGoal(int goal)
        {
            CalorieGoal = goal;
        }
    }

    private void label1_Click(object sender, EventArgs e)
    {

    }

    private void textBoxUsername_TextChanged(object sender, EventArgs e)
    {

    }

    private void labelMetric3_Click(object sender, EventArgs e)
    {

    }

    private void labelMetric1_Click(object sender, EventArgs e)
    {

    }

    private void buttonLogin_Click(object sender, EventArgs e)
    {
        string username = textBoxUsername.Text;//username input
        string password = textBoxPassword.Text;//password input

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();//user login to the database if the user exist in the database 

            string loginQuery = "SELECT Password, CalorieGoal FROM Users WHERE Username = @username";
            SqlCommand loginCmd = new SqlCommand(loginQuery, connection);
            loginCmd.Parameters.AddWithValue("@username", username);

            using (SqlDataReader reader = loginCmd.ExecuteReader())
            {
                if (reader.Read())//reader object that has both username and password obtained form the database
                {
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
                    string storedPassword = reader["Password"].ToString();
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
                    if (storedPassword == password)//comparison of the user provided password and the password obtained from the database
                    {
                        int calorieGoal = (int)reader["CalorieGoal"];//if the password matches then obtaing the variable for the calorific value
                        currentUser = new User(username, password, calorieGoal);
                        MessageBox.Show("Login successful!");

                        // in the windows form enable the  goal setting and activity tracking after login was successful
                        labelGoal.Visible = true;
                        textBoxGoal.Visible = true;
                        buttonSetGoal.Visible = true;
                        labelActivity.Visible = true;
                        comboBoxActivity.Visible = true;
                        labelMetric1.Visible = true;
                        labelMetric2.Visible = true;
                        labelMetric3.Visible = true;
                        textBoxMetric1.Visible = true;
                        textBoxMetric2.Visible = true;
                        textBoxMetric3.Visible = true;
                        buttonRecordActivity.Visible = true;
                        labelProgress.Visible = true;
                        labelCaloriesBurned.Visible = true;
                        Progressbutton.Visible = true;

                        labelUsername.Visible = false;
                        textBoxUsername.Visible = false;
                        labelPassword.Visible = false;
                        textBoxPassword.Visible = false;
                        label1.Visible = false;
                        buttonLogin.Visible = false;
                        buttonRegister.Visible = false;

                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password. Try again");//failed to login after the user provided wrong password of user nama
                    }
                }
                else
                {
                    MessageBox.Show("User not found.Rigester");
                }
            }
        }
    }

    private void buttonRegister_Click(object sender, EventArgs e)
    {
        string username = textBoxUsername.Text;//get the information from the form text box and insert it in the username string variable
        string password = textBoxPassword.Text;//get the information from the form password textbox and insert it in the password string  variable
                                               //use the IsValidUsername() IsValidPassword() to check the validity of the entered username and password by the user
        if (!IsValidUsername(username) || !IsValidPassword(password))
        {
            MessageBox.Show("Invalid username or password format.");
            return;
        }
        //connecting to the Ms SQL database defined by the connection string
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            // Checking  if user pre-exist or not
            string checkUserQuery = "SELECT COUNT(*) FROM Users WHERE Username = @username";
            SqlCommand checkCmd = new SqlCommand(checkUserQuery, connection);
            checkCmd.Parameters.AddWithValue("@username", username);
            int userExists = (int)checkCmd.ExecuteScalar();

            if (userExists == 0)//if the checkCmd.ExecuteScalar() returns zero then the user does not exist
            {
                // if the user does not exist the add a new user
                string insertUserQuery = "INSERT INTO Users (Username, Password, CalorieGoal) VALUES (@username, @password, 0)";
                SqlCommand insertCmd = new SqlCommand(insertUserQuery, connection);
                insertCmd.Parameters.AddWithValue("@username", username);
                insertCmd.Parameters.AddWithValue("@password", password);
                insertCmd.ExecuteNonQuery();

                MessageBox.Show("User registered successfully!");//database feedback
            }
            else
            {
                MessageBox.Show("Username already exists.");//if checkCmd.ExecuteScalar() retuns a non zero value then the user exist
            }
        }
    }

    private void buttonSetGoal_Click(object sender, EventArgs e)
    {
        int goal;
        if (int.TryParse(textBoxGoal.Text, out goal))
        {
            currentUser.SetCalorieGoal(goal);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();//connect to the database through the connection string 

                string updateGoalQuery = "UPDATE Users SET CalorieGoal = @goal WHERE Username = @username";
                SqlCommand updateCmd = new SqlCommand(updateGoalQuery, connection);
                updateCmd.Parameters.AddWithValue("@goal", goal);
                updateCmd.Parameters.AddWithValue("@username", currentUser.Username);
                updateCmd.ExecuteNonQuery();

                MessageBox.Show($"Goal set to {goal} calories.");
            }
        }
        else
        {
            MessageBox.Show("Invalid goal input. Try again with the correct goal");
        }
    }

    private ComboBox GetComboBoxActivity()
    {
        return comboBoxActivity;
    }

    private void buttonRecordActivity_Click(object sender, EventArgs e)
    {
        try { 
        string activity = comboBoxActivity.SelectedItem.ToString();
        int metric1 = int.Parse(textBoxMetric1.Text);
        int metric2 = int.Parse(textBoxMetric2.Text);
        int metric3 = int.Parse(textBoxMetric3.Text);
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();//connection to the database through the connection string

            string insertActivityQuery = "INSERT INTO Activities (Username, ActivityName, Metric1, Metric2, Metric3) VALUES (@username, @activity, @metric1, @metric2, @metric3)";
            SqlCommand insertCmd = new SqlCommand(insertActivityQuery, connection);
            insertCmd.Parameters.AddWithValue("@username", currentUser.Username);
            insertCmd.Parameters.AddWithValue("@activity", activity);
            insertCmd.Parameters.AddWithValue("@metric1", metric1);
            insertCmd.Parameters.AddWithValue("@metric2", metric2);
            insertCmd.Parameters.AddWithValue("@metric3", metric3);
            insertCmd.ExecuteNonQuery();

            MessageBox.Show($"{activity} activity recorded.");
        }
        }
        catch { MessageBox.Show("Ivalid input or empty statement"); }
    }



private void Progressbutton_Click(object sender, EventArgs e)
{
    int totalCaloriesBurned = 0;

    using (SqlConnection connection = new SqlConnection(connectionString))
    {
        connection.Open();

        string activitiesQuery = "SELECT ActivityName, Metric1, Metric2, Metric3 FROM Activities WHERE Username = @username";
        SqlCommand activitiesCmd = new SqlCommand(activitiesQuery, connection);
        activitiesCmd.Parameters.AddWithValue("@username", currentUser.Username);

        using (SqlDataReader reader = activitiesCmd.ExecuteReader())
        {
            while (reader.Read())
            {
                string activity = reader["ActivityName"].ToString();
                int metric1 = (int)reader["Metric1"];
                int metric2 = (int)reader["Metric2"];
                int metric3 = (int)reader["Metric3"];

                totalCaloriesBurned += CalculateCalories(activity, new List<int> { metric1, metric2, metric3 });


            }
        }

        labelCaloriesBurned.Text = $"Calories burned: {totalCaloriesBurned}/{currentUser.CalorieGoal}";
        if (totalCaloriesBurned >= currentUser.CalorieGoal)
        {
            MessageBox.Show("Goal achieved!");
        }
        else
        {
            MessageBox.Show("Keep going!");
        }
    }
    //function returns the progress if the activity is walking or swimming  or else it return zero
    static int CalculateCalories(string activity, List<int> metrics)
    {
        // formulas for walking and swimming
        if (activity == "Walking")
            return (metrics[0] / 20) + (metrics[1] / 100) + (metrics[2] * 5);
        if (activity == "Swimming")
            return (metrics[0] * 2) + (metrics[1] * 5) + (metrics[2] / 2);
        if (activity == "Cycling")
            return (metrics[0] / 20) + (metrics[1] / 100) + (metrics[2] * 5);
        if (activity == "Running")
            return (metrics[0] * 2) + (metrics[1] * 5) + (metrics[2] / 2);
        if (activity == "Yoga")
            return (metrics[0] / 20) + (metrics[1] / 100) + (metrics[2] * 5);
        if (activity == "Jumping Rope")
            return (metrics[0] * 2) + (metrics[1] * 5) + (metrics[2] / 2);

        return 0;
    }

    //this function checks whether the username is correct using reqirements 
    // private bool IsValidUsername(string username)
    // {
    //    return Regex.IsMatch(username, "^[a-zA-Z0-9]+$");
    // }
    //function returns a true if password total count is 12 character and has a lower anf upper case letters.
    // private bool IsValidPassword(string password)
    // {
    //    return password.Length == 12 && Regex.IsMatch(password, "[a-z]") && Regex.IsMatch(password, "[A-Z]");
    // }
}

private void label1_Click_1(object sender, EventArgs e)
{

}
}

